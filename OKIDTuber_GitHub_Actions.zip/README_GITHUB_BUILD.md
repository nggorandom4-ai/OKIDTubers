# OKIDTuber — Build APK via GitHub Actions

1. Buat repository baru di GitHub.
2. Upload seluruh isi project ini, termasuk folder `.github`.
3. Buka tab **Actions**.
4. Pilih workflow **Build OKIDTuber APK**.
5. Tekan **Run workflow**.
6. Tunggu build selesai.
7. Buka hasil workflow → bagian **Artifacts** → download `OKIDTuber-debug-apk`.
8. Extract ZIP artifact tersebut untuk mendapatkan file `.apk`.

Workflow juga otomatis build setiap kali ada push ke branch `main` atau `master`.
