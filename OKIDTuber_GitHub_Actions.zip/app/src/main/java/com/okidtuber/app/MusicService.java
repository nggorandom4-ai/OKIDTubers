package com.okidtuber.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class MusicService extends MediaSessionService {
    private ExoPlayer player;
    private MediaSession session;

    @Override public void onCreate() {
        super.onCreate();
        player = new ExoPlayer.Builder(this).build();
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        session = new MediaSession.Builder(this, player).setSessionActivity(pi).build();
    }

    public void playUrl(String url, String title, String artist) {
        MediaMetadata md = new MediaMetadata.Builder().setTitle(title == null ? "OKIDTuber" : title).setArtist(artist == null ? "OKIDTuber" : artist).build();
        MediaItem item = new MediaItem.Builder().setUri(Uri.parse(url)).setMediaMetadata(md).build();
        player.setMediaItem(item); player.prepare(); player.play();
    }
    public void pauseMusic(){ player.pause(); }
    public void resumeMusic(){ player.play(); }
    public void stopMusic(){ player.stop(); }
    public ExoPlayer getPlayer(){ return player; }
    @Override public MediaSession onGetSession(androidx.media3.session.MediaSession.ControllerInfo controllerInfo){ return session; }
    @Override public void onDestroy(){ if(session!=null) session.release(); if(player!=null) player.release(); super.onDestroy(); }
}
