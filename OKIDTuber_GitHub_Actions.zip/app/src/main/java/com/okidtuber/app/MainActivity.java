package com.okidtuber.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import android.view.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView web; MusicService service;
    ServiceConnection connection = new ServiceConnection(){ public void onServiceConnected(ComponentName n, IBinder b){} public void onServiceDisconnected(ComponentName n){} };
    @Override protected void onCreate(Bundle b){ super.onCreate(b);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);
        web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.setBackgroundColor(0xFF090D18);
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        web.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String url){ inject(); }});
        web.loadUrl("file:///android_asset/index.html");
        Intent i=new Intent(this,MusicService.class); startService(i); bindService(i,connection,Context.BIND_AUTO_CREATE);
    }
    void inject(){ web.evaluateJavascript("(function(){const p=HTMLMediaElement.prototype.play, q=HTMLMediaElement.prototype.pause; HTMLMediaElement.prototype.play=function(){try{if(window.AndroidBridge&&this.src){AndroidBridge.play(this.src,document.title||'OKIDTuber','OKIDTuber');return Promise.resolve();}}catch(e){} return p.call(this)}; HTMLMediaElement.prototype.pause=function(){try{if(window.AndroidBridge)AndroidBridge.pause()}catch(e){} return q.call(this)};})();",null); }
    class Bridge { @JavascriptInterface public void play(String url,String title,String artist){ runOnUiThread(()->{ if(service!=null) service.playUrl(url,title,artist); }); }
        @JavascriptInterface public void pause(){ runOnUiThread(()->{if(service!=null)service.pauseMusic();}); }
    }
    @Override protected void onDestroy(){ try{unbindService(connection);}catch(Exception ignored){} super.onDestroy(); }
}
