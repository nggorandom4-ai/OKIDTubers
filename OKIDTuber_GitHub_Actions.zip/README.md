# OKIDTuber Android APK-ready project

Project ini membungkus UI OKIDTuber ke Android WebView dan memakai AndroidX Media3/ExoPlayer + MediaSessionService untuk playback background dan kontrol media/notifikasi Android.

## Build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle mengunduh dependency.
3. Run ke HP atau Build > Generate APK.

Catatan: proyek ini memerlukan internet untuk dependency Gradle dan API OKIDTuber. UI utama berada di `app/src/main/assets/index.html`.
